import { parseDSL } from "../dsl/parseDSL.js";
import { renderJSON, renderMermaid, renderDiagram, renderJS } from "./render.js";
import { setError, clearError } from "./errors.js";
import { dom } from "./constants.js";

export function updateAllOutputs(dslText) {
	try {
		const parsed = parseDSL(dslText.trim());
		renderJSON(parsed, dom.jsonOutput);
		const mermaidCode = renderMermaid(parsed);
		dom.mermaidCodeOutput.textContent = mermaidCode;
		renderDiagram(mermaidCode, dom.diagramDiv);
		renderJS(parsed, dom.jsOutput);
		clearError();
	} catch (err) {
		setError(err.message, dom);
	}
}