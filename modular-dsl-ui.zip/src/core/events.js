import { dom, examples } from "./constants.js";
import { updateAllOutputs } from "./update.js";

export function bindUIEvents() {
	let debounceTimer = null;

	dom.dslInput.addEventListener("input", () => {
		if (!dom.liveUpdateCheckbox.checked) return;
		clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => updateAllOutputs(dom.dslInput.value), 300);
	});

	dom.dslInput.addEventListener("keydown", e => {
		if (e.key === "Tab") {
			e.preventDefault();
			const start = dom.dslInput.selectionStart;
			const end = dom.dslInput.selectionEnd;
			const val = dom.dslInput.value;
			dom.dslInput.value = val.slice(0, start) + "  " + val.slice(end);
			dom.dslInput.selectionStart = dom.dslInput.selectionEnd = start + 2;
		}
	});

	dom.exampleSelect.addEventListener("change", () => {
		const idx = parseInt(dom.exampleSelect.value, 10);
		dom.dslInput.value = examples[idx];
		updateAllOutputs(dom.dslInput.value);
	});

	dom.themeSelect.addEventListener("change", () => {
		document.body.className = "";
		document.body.classList.add(dom.themeSelect.value);
	});

	document.querySelectorAll("pre").forEach(pre => {
		pre.setAttribute("title", "Double-click to zoom in/out");
		pre.addEventListener("dblclick", () => {
			pre.classList.toggle("fullscreen-pre");
		});
	});
}