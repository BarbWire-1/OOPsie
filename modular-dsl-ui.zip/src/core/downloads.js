import { generateMermaid } from "../generateMermaid.js";
import { generateJS } from "../generateJS.js";
import { parseDSL } from "../dsl/parseDSL.js";
import { dom } from "./constants.js";
import { setError } from "./errors.js";

function generateMarkdown({ dsl, json, mermaid, js }) {
	return \`
# DSL Input
\`\`\`yaml
\${dsl}
\`\`\`

# Parsed JSON
\`\`\`json
\${json}
\`\`\`

# Mermaid Diagram
\`\`\`mermaid
\${mermaid}
\`\`\`

# Generated JS
\`\`\`js
\${js}
\`\`\`
\`.trim();
}

function downloadFile(filename, content, type = "text/markdown") {
	const blob = new Blob([ content ], { type });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
}

export function initDownloadHandlers() {
	dom.downloadMdBtn.addEventListener("click", () => {
		try {
			const parsed = parseDSL(dom.dslInput.value);
			const json = JSON.stringify(parsed, null, 2);
			const mermaid = generateMermaid(parsed);
			const js = generateJS(parsed);
			const markdown = generateMarkdown({ dsl: dom.dslInput.value, json, mermaid, js });
			downloadFile("sketch-output.md", markdown);
		} catch (err) {
			setError(err.message, dom);
		}
	});

	dom.downloadSvgBtn.addEventListener("click", () => {
		const svg = dom.diagramDiv.querySelector("svg");
		if (!svg) return alert("No diagram to download!");
		const clone = svg.cloneNode(true);
		clone.setAttribute("width", "800");
		clone.setAttribute("height", "600");

		if (!clone.hasAttribute("viewBox")) {
			const w = clone.getAttribute("width");
			const h = clone.getAttribute("height");
			clone.setAttribute("viewBox", \`0 0 \${w} \${h}\`);
		}

		const svgData = new XMLSerializer().serializeToString(clone);
		downloadFile("diagram.svg", svgData, "image/svg+xml");
	});
}