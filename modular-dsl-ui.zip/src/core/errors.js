export function setError(message, { jsonOutput, mermaidCodeOutput, diagramDiv, jsOutput }) {
	jsonOutput.textContent = "Invalid DSL: " + message;
	mermaidCodeOutput.textContent = "";
	diagramDiv.innerHTML = "";
	jsOutput.querySelector("code").textContent = "";
}

export function clearError() {
	// Optional UI cleanup
}