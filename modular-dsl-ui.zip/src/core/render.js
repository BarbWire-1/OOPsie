import { generateMermaid } from "../generateMermaid.js";
import { generateJS } from "../generateJS.js";

export function renderJSON(parsed, outputEl) {
	outputEl.textContent = JSON.stringify(parsed, null, 2);
}

export function renderMermaid(parsed) {
	return generateMermaid(parsed);
}

export function renderDiagram(code, diagramEl) {
	diagramEl.innerHTML = `<div class="mermaid">\${code}</div>`;
	mermaid.init(undefined, diagramEl.querySelectorAll(".mermaid"));
}

export function renderJS(parsed, outputEl) {
	const jsCode = generateJS(parsed);
	const codeEl = outputEl.querySelector("code");
	codeEl.textContent = jsCode;
	Prism.highlightElement(codeEl);
}