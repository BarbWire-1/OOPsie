import { game, game2, ttt, simpleSketch } from "../testSketches/exampleSketches.js";

export const examples = [ game, game2, ttt, simpleSketch ];

export const dom = {
	themeSelect: document.getElementById("theme-select"),
	exampleSelect: document.getElementById("example-select"),
	dslInput: document.getElementById("dsl-input"),
	jsonOutput: document.getElementById("json-output"),
	mermaidCodeOutput: document.getElementById("mermaid-code-output"),
	jsOutput: document.getElementById("js-output"),
	diagramDiv: document.getElementById("diagram"),
	liveUpdateCheckbox: document.getElementById("live-update-checkbox"),
	downloadMdBtn: document.getElementById("download-md-btn"),
	downloadSvgBtn: document.getElementById("download-svg-btn"),
};