import { dom, examples } from "./core/constants.js";
import { updateAllOutputs } from "./core/update.js";
import { bindUIEvents } from "./core/events.js";
import { initDownloadHandlers } from "./core/downloads.js";

mermaid.initialize({ startOnLoad: false });

const defaultExample = 1;
dom.dslInput.value = examples[defaultExample];
dom.exampleSelect.value = defaultExample;
updateAllOutputs(dom.dslInput.value);

bindUIEvents();
initDownloadHandlers();